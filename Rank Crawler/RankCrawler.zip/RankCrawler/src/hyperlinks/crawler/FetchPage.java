/**
 *
 * Class FetchPage is used to download the web page,parse the web page and
 * differentiate various tags in the web.
 *
 *
 */
package hyperlinks.crawler;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public final class FetchPage {

    URL url;
    URL newurl;

    Document file;
    Document parseFile;

    Elements media;
    Elements links;
    Elements imports;
    Elements body;
    Elements span;
    Elements title;
    Elements heading1;
    Elements heading2;
    Elements heading3;
    Elements heading4;
    Elements heading5;
    Elements heading6;

    int pageWeight;
    int totalWeight;
    int URLWeight;
    int bodyWeight;
    int titleWeight;
    int keywordWeight;
    int descWeight;
    int h1Weight;
    int Stringcount;

    String metadescription;
    String metakeywords;
    String description;
    String keywords;
    String find;

    ArrayList<String> otherurls = new ArrayList();

    @SuppressWarnings("empty-statement")

    public FetchPage(URL url, String search) {
        try {

            this.url = url;
            this.file = Jsoup.connect(url.toString()).timeout(100000000).get();

            this.parseFile = Jsoup.parse(this.file.toString());
            this.body = this.file.getElementsByTag("body");
            this.links = this.file.getElementsByTag("a");

            this.title = this.file.getElementsByTag("title");
            this.heading1 = this.file.getElementsByTag("h1");

            this.metadescription = getMetadesc(this.parseFile);

            if (this.metadescription != null) {
                this.metadescription = stripSpecialCharacters(this.metadescription.toLowerCase());
            }

            this.metakeywords = getMetakey(this.parseFile);

            if (this.metakeywords != null) {
                this.metakeywords = stripSpecialCharacters(this.metakeywords).toLowerCase();
            }
            this.find = search;

        } catch (IOException ex) {
            String name = " " + ex.getCause() + " " + ex.getMessage() + " " + ex.getClass();
            RankLogger log = new RankLogger();
            log.getLogger(name);
        }
    }

    /**
     *
     *
     * returnPageWeight function calculate and return the page weight of the Web
     * page .
     *
     * @return
     */
    public int returnPageWeight()throws NullPointerException{

        try {
            this.totalWeight = 0;
            this.URLWeight = 4;
            this.keywordWeight = 5;
            this.h1Weight = 3;
            this.descWeight = 5;
            this.bodyWeight = 1;
            this.titleWeight = 2;

            String urlTostring = this.url.toString();
            String bodyTostring = this.body.toString();
            String titleTostring = this.title.toString();
            String h1Tostring = this.heading1.toString();

            if (urlTostring.contains(this.find)) {

                this.totalWeight = this.totalWeight + this.URLWeight;
            }

            bodyTostring = stripSpecialCharacters(bodyTostring).toLowerCase();

            if (bodyTostring != null) {
                Stringcount = returnCount(bodyTostring, this.find);

                if (Stringcount > 0) {
                    this.totalWeight = this.totalWeight + (this.bodyWeight * Stringcount);
                }
            }

            if (this.metakeywords != null) {
                Stringcount = returnCount(this.metakeywords, this.find);

                if (Stringcount > 0) {
                    this.totalWeight = this.totalWeight + (this.keywordWeight * Stringcount);
                }
            }

            if (this.metadescription != null) {
                Stringcount = returnCount(this.metadescription, this.find);

                if (Stringcount > 0) {
                    this.totalWeight = this.totalWeight + (this.descWeight * Stringcount);
                }
            }

            if (titleTostring != null) {
                titleTostring = stripSpecialCharacters(titleTostring).toLowerCase();
                Stringcount = returnCount(titleTostring, this.find);

                if (Stringcount > 0) {
                    this.totalWeight = this.totalWeight + (this.titleWeight * Stringcount);
                }
            }

            if (h1Tostring != null) {
                h1Tostring = stripSpecialCharacters(h1Tostring).toLowerCase();
                Stringcount = returnCount(h1Tostring, this.find);
                if (Stringcount > 0) {
                    this.totalWeight = this.totalWeight + (this.h1Weight * Stringcount);
                }
            }

            if (this.totalWeight > 0) {
                return this.totalWeight;
            } else {
                return -1;
            }
        } catch (NullPointerException ex) {
            String name = new Object() {}.getClass().getEnclosingMethod().getName();
            name = name + "\nDetails: " + " " + name + " " + ex.getCause() + " " + ex.getMessage() + " " + ex.getClass();
            RankLogger log = new RankLogger();
            log.getLogger(name);
            return 0;
        }

    }

    /**
     *
     * getMetadesc function extracts the Meta information about description in
     * the web page.
     *
     * @param doc
     * @return
     */
    public final String getMetadesc(Document doc) {

        try {
            this.description = doc.select("meta[name=description]").get(0).attr("content");

        } catch (Exception ex) {
        }
        return this.description;
    }

    /**
     *
     * getMetakey function extracts the Meta information about keywords in the
     * web page.
     *
     * @param doc
     * @return
     */
    public final String getMetakey(Document doc) {

        try {
            this.keywords = doc.select("meta[name=keywords]").first().attr("content");

        } catch (Exception ex) {
        }
        return this.keywords;
    }

    /**
     *
     * returnCount function return the number of occurrence of search string in
     * the main string.
     *
     * @param str
     * @param subStr
     * @return
     */
    public int returnCount(String str, String subStr) {
        if (str != null && subStr != null) {
            return ((str.length() - str.replace(subStr, "").length()) / subStr.length());
        }
        return 0;
    }

    /**
     *
     *
     * stripSpecialCharacters function is used to remove special characters from
     * the provided String.
     *
     * @param str
     * @return
     */
    public static String stripSpecialCharacters(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (Character.isLetter(ch)) {
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    public ArrayList<String> otherUrls() throws MalformedURLException, NullPointerException{
        try {
            for (Iterator<Element> it = this.links.iterator(); it.hasNext();) {
                Element eachurl = it.next();
                String href = eachurl.attr("href");
                if (href != null) {
                    if ((href.startsWith("http")) && (!href.startsWith("https"))) {
                        this.newurl = new URL(href);
                        String newone = this.newurl.getProtocol() + "://" + this.newurl.getHost();
                        this.otherurls.add(newone);
                    }
                } else {
                }
            }
        } catch (MalformedURLException|NullPointerException ex) {
            String name = new Object() {
            }.getClass().getEnclosingMethod().getName();
            name = name + "\nDetails: " + " " + name + " " + ex.getCause() + " " + ex.getMessage() + " " + ex.getClass();
            RankLogger log = new RankLogger();
            log.getLogger(name);
        }
        removeDuplicates(this.otherurls);
        return this.otherurls;
    }

    /**
     *
     *
     * removeDuplicates function removes the duplicates URL's from the frontier.
     *
     * @param arlist
     */
    public void removeDuplicates(ArrayList<String> arlist) {

        HashSet<String> hs = new HashSet(arlist);
        this.otherurls.clear();
        this.otherurls.addAll(hs);

    }

}
