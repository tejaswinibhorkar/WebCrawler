/**
 *
 * Class RankLogger is used to log the different error messages into the log
 * file.
 *
 *
 */
package hyperlinks.crawler;

/**
 *
 * @author Rank-Crawler Group
 */
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class RankLogger {

    /**
     *
     *
     * getLogger function is used to log the Error messages from application
     * during runtime
     *
     * @param theMessage
     */
    public void getLogger(String theMessage) {
        Logger logger = Logger.getLogger("MyLog");
        try {
            // This block configure the logger with handler and formatter  
            FileHandler fh = new FileHandler("D:\\RankCrawlerLog.log", true);
            logger.addHandler(fh);
            SimpleFormatter formatter = new SimpleFormatter();
            fh.setFormatter(formatter);
            // the following statement is used to log any messages   
            logger.info(theMessage);
        } catch (IOException | SecurityException e) {
        }
    }
}
