/**
 *
 * Class URLQueue is used to provide various facilities such as creating URL
 * queue ,insertion deletion from the URL queue And similar functionalities.
 *
 */
package hyperlinks.crawler;

import java.util.LinkedList;

public class URLQueue {

    private LinkedList list;

    /**
     *
     * URLQueue function creates a URL queue.
     *
     */
    public URLQueue() {
        this.list = new LinkedList();
    }

    /**
     *
     * isEmpty function check for empty URL queue
     *
     * @return
     */
    public boolean isEmpty() {
        return this.list.size() == 0;
    }

    /**
     *
     * enqueue function add URL at top in the URL queue .
     *
     * @param item
     */
    public void enqueue(Object item) {
        this.list.addLast(item);
    }

    /**
     *
     * dequeue function remove and return URL at top in the URL queue.
     *
     * @return
     */
    public Object dequeue() {
        Object item = this.list.getFirst();
        this.list.removeFirst();

        return item;
    }

    /**
     *
     * peek function return URL at top in the URL queue .
     *
     * @return
     */
    public Object peek() {
        return this.list.get(1);
    }

    /**
     *
     * printQueue print the URL queue on Console.
     *
     */
    void printQueue(URLQueue urlqueue) {
        System.out.println(this.list);
    }

    /**
     *
     * size function return the count of URL in the URL queue.
     *
     */
    int size() {
        return this.list.size();
    }

    /**
     *
     * clear function remove all URL in the URL queue.
     *
     */
    void clear() {
        this.list.clear();
    }

    /**
     *
     * hasThis function return true when the given URL is present in the URL
     * queue
     *
     */
    boolean hasThis(String tobefetched) {
        return this.list.contains(tobefetched);
    }
}
