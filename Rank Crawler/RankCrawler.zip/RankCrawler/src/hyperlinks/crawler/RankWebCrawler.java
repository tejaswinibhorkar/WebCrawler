/**
 *
 * Content Relevance Prediction Algorithm in Web Crawlers to Enhance Web Search
 */
package hyperlinks.crawler;

import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.FileDialog;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.*;
import javax.swing.*;

/**
 *
 * @author Rank-Crawler Group
 */
/**
 *
 * This class contains the main() function which is used to built GUI and its
 * GUI associated code.
 */
public class RankWebCrawler extends javax.swing.JFrame {

    public RankWebCrawler() {
        this.setResizable(false);
        this.setTitle("RankBot Web Spider");
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        URLLabel = new javax.swing.JLabel();
        StringLabel = new javax.swing.JLabel();
        URLTextField = new javax.swing.JTextField();
        StringTextField = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        crawlAlgorithmBox = new javax.swing.JCheckBox();
        CrawlButton = new javax.swing.JButton();
        ClearButton = new javax.swing.JButton();
        HelpButton = new javax.swing.JButton();
        AboutButton = new javax.swing.JButton();
        NumberLabel = new javax.swing.JLabel();
        NumberOfPagesTextField = new javax.swing.JTextField();
        iconLabel = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        relevantCount = new javax.swing.JLabel();
        ExportRelButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        resultArea = new java.awt.TextArea();
        relevantCountText = new java.awt.TextField();
        totalCount = new javax.swing.JLabel();
        timeCount = new javax.swing.JLabel();
        totalCountText = new java.awt.TextField();
        timeCountText = new java.awt.TextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        URLLabel.setText("URL:");

        StringLabel.setText("String:");

        URLTextField.setText("http://");
        URLTextField.setToolTipText("Enter seed URL which will be starting point for crawler");
        URLTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                URLTextFieldActionPerformed(evt);
            }
        });

        StringTextField.setToolTipText("Enter String which crawler have to search for");
        StringTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StringTextFieldActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(URLLabel)
                    .addComponent(StringLabel))
                .addGap(55, 55, 55)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(URLTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 540, Short.MAX_VALUE)
                    .addComponent(StringTextField))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(URLLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(URLTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StringLabel)
                    .addComponent(StringTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        crawlAlgorithmBox.setSelected(true);
        crawlAlgorithmBox.setText("Crawling Algorithm");
        crawlAlgorithmBox.setToolTipText("Check if you want to crawl on given URL to search given string");
        crawlAlgorithmBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                crawlAlgorithmBoxActionPerformed(evt);
            }
        });

        CrawlButton.setBackground(new java.awt.Color(204, 204, 204));
        CrawlButton.setText("CRAWL");
        CrawlButton.setToolTipText("Click to start crawling on given URL");
        CrawlButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrawlButtonActionPerformed(evt);
            }
        });

        ClearButton.setBackground(new java.awt.Color(204, 204, 204));
        ClearButton.setText("CLEAR");
        ClearButton.setToolTipText("Clear list displayed below");
        ClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearButtonActionPerformed(evt);
            }
        });

        HelpButton.setBackground(new java.awt.Color(204, 204, 204));
        HelpButton.setText("HELP");
        HelpButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        HelpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HelpButtonActionPerformed(evt);
            }
        });

        AboutButton.setBackground(new java.awt.Color(204, 204, 204));
        AboutButton.setText("ABOUT");
        AboutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AboutButtonActionPerformed(evt);
            }
        });

        NumberLabel.setText("Number of URL to visit:");

        NumberOfPagesTextField.setText("75");
        NumberOfPagesTextField.setToolTipText("Range 5 to 150");
        NumberOfPagesTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NumberOfPagesTextFieldActionPerformed(evt);
            }
        });

        iconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hyperlinks/crawler_UIFiles/Webcrawer.gif"))); // NOI18N
        iconLabel.setText("jLabel4");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(NumberLabel)
                        .addGap(18, 18, 18)
                        .addComponent(NumberOfPagesTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(crawlAlgorithmBox))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(CrawlButton)
                        .addGap(40, 40, 40)
                        .addComponent(ClearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(HelpButton, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addComponent(AboutButton)))
                .addGap(48, 48, 48)
                .addComponent(iconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(NumberOfPagesTextField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NumberLabel)
                            .addComponent(crawlAlgorithmBox))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CrawlButton)
                            .addComponent(ClearButton)
                            .addComponent(HelpButton)
                            .addComponent(AboutButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(iconLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        relevantCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        relevantCount.setText("Relevant Count");

        ExportRelButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hyperlinks/crawler_UIFiles/export.png"))); // NOI18N
        ExportRelButton.setToolTipText("Save list to location");
        ExportRelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExportRelButtonActionPerformed(evt);
            }
        });

        jLabel6.setText(" List of Relevant Links (URL : Weight)");

        resultArea.setEditable(false);

        relevantCountText.setBackground(new java.awt.Color(255, 255, 255));
        relevantCountText.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        relevantCountText.setEditable(false);
        relevantCountText.setText("0");
        relevantCountText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                relevantCountTextActionPerformed(evt);
            }
        });

        totalCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        totalCount.setText("Total Links Crawled");

        timeCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        timeCount.setText("Total Time (in milliseconds)");

        totalCountText.setBackground(new java.awt.Color(255, 255, 255));
        totalCountText.setEditable(false);
        totalCountText.setText("0");
        totalCountText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalCountTextActionPerformed(evt);
            }
        });

        timeCountText.setBackground(new java.awt.Color(255, 255, 255));
        timeCountText.setEditable(false);
        timeCountText.setPreferredSize(new java.awt.Dimension(60, 35));
        timeCountText.setText("0");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setText("EXPORT");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(resultArea, javax.swing.GroupLayout.PREFERRED_SIZE, 508, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGap(21, 21, 21)
                                        .addComponent(ExportRelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGap(53, 53, 53)
                                        .addComponent(jLabel1))))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(relevantCount)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(relevantCountText, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(161, 161, 161)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(totalCount, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(timeCount))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(totalCountText, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(timeCountText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(54, 54, 54)))))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(resultArea, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ExportRelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(relevantCount, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(timeCount)
                            .addComponent(totalCount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(relevantCountText, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(totalCountText, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeCountText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     *
     * CrawlButtonActionPerformed executes the algorithm for crawling. This is
     * defined by InternalMechanism()
     */

    private void CrawlButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrawlButtonActionPerformed
        // TODO add your handling code here:
        if (("http://".equals(this.URLTextField.getText())) || ("".equals(this.URLTextField.getText()))) {
            JOptionPane.showMessageDialog(null, "\n\nCheck the URL properly\n\n", "ERROR", 1);
        } else if ((0 > Integer.parseInt(this.NumberOfPagesTextField.getText()) || (1001 < Integer.parseInt(this.NumberOfPagesTextField.getText())))) {
            JOptionPane.showMessageDialog(null, "\n\nCheck the number of URL to crawl(range 5-1001)\n\n", "ERROR", 1);
        } else {
            try {
                this.URLTextField.setEnabled(false);
                this.StringTextField.setEnabled(false);
                this.NumberOfPagesTextField.setEnabled(false);
                InternalMechanism();
            } catch (MalformedURLException ex) {
                String name = new Object() {
                }.getClass().getEnclosingMethod().getName();
                name = name + "\nDetails: " + " " + name + " " + ex.getCause() + " " + ex.getMessage() + " " + ex.getClass();
                RankLogger log = new RankLogger();
                log.getLogger(name);
            }
        }
    }//GEN-LAST:event_CrawlButtonActionPerformed
    /**
     *
     * ClearButtonActionPerformed executes the clearing of text areas. It sets
     * every value to its defaults.
     */

    private void ClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearButtonActionPerformed
        // TODO add your handling code here:
        setCursor(Cursor.getDefaultCursor());
        this.resultArea.setText("");
        this.relevantCountText.setText(Integer.toString(0));
        this.URLTextField.setEnabled(true);
        this.StringTextField.setEnabled(true);
        this.NumberOfPagesTextField.setEnabled(true);
    }//GEN-LAST:event_ClearButtonActionPerformed

    /**
     *
     * AboutButtonActionPerformed displays information about Developers and
     * Mentors of project
     *
     */

    private void AboutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AboutButtonActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null, "Rajiv Gandhi College of Engineering and Research \n\nDevelopers:\n\n 1. Pritam Bhowmik\n 2. Shraddha Shahare\n 3. Tejaswini Bhorkar\n 4. Saurabh Pakkhide\n 5. Jaya Rajurkar\n\nProject Guides:\n\n1. Prof Prashant Dahiwale(RGCER CSE Department)\n2. Mr.Bhushan Fegade(Persistent Systems)\n\n THANK YOU!!!\n\n WE WISH YOU A HAPPY NEW YEAR !!", "ABOUT", 1);
    }//GEN-LAST:event_AboutButtonActionPerformed

    /**
     *
     * HelpButtonActionPerformed views all the GUI related instruction display.
     * It uses Google Drive as the medium.
     *
     *
     */

    private void HelpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HelpButtonActionPerformed
        // TODO add your handling code here:
        try {
            String imageFilePath = "https://docs.google.com/file/d/0B997VKyks0FpMW9zaS1KWk13Tlk/edit?usp=sharing";
            Desktop.getDesktop().browse(new URL(imageFilePath).toURI());
        } catch (URISyntaxException | IOException ex) {
            String name = new Object() {
            }.getClass().getEnclosingMethod().getName();
            name = name + "\nDetails: " + " " + name + " " + ex.getCause() + " " + ex.getMessage() + " " + ex.getClass();
            RankLogger log = new RankLogger();
            log.getLogger(name);
        }
    }//GEN-LAST:event_HelpButtonActionPerformed

    private void StringTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StringTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StringTextFieldActionPerformed

    private void URLTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_URLTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_URLTextFieldActionPerformed

    private void crawlAlgorithmBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_crawlAlgorithmBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_crawlAlgorithmBoxActionPerformed

    private void relevantCountTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_relevantCountTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_relevantCountTextActionPerformed
    /**
     *
     * ExportRelButtonActionPerformed function save the result of crawling
     * process into a text file
     *
     */
    private void ExportRelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExportRelButtonActionPerformed
        {
            try {
                String s = resultArea.getText();
                if (s.length() > 0) {
                    FileDialog fd = new FileDialog(this, "Save File As", FileDialog.SAVE);
                    fd.setFile("SpiderOutput.txt");
                    fd.setDirectory("D:\\RankExport\\SpiderOutput.doc");
                    fd.setVisible(true);
                    String path = fd.getDirectory() + fd.getFile();
                    try (FileOutputStream fos = new FileOutputStream(path)) {
                        byte[] b = s.getBytes();
                        fos.write(b);
                    }
                }
            } catch (IOException ex) {
                String name = new Object() {
                }.getClass().getEnclosingMethod().getName();
                name = name + "\n Details: " + " " + name + " " + ex.getCause() + " " + ex.getMessage() + " " + ex.getClass();
                RankLogger log = new RankLogger();
                log.getLogger(name);
            }
        }        // TODO add your handling code here:
    }//GEN-LAST:event_ExportRelButtonActionPerformed

    private void totalCountTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalCountTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalCountTextActionPerformed

    private void NumberOfPagesTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NumberOfPagesTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NumberOfPagesTextFieldActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AboutButton;
    private javax.swing.JButton ClearButton;
    private javax.swing.JButton CrawlButton;
    private javax.swing.JButton ExportRelButton;
    private javax.swing.JButton HelpButton;
    private javax.swing.JLabel NumberLabel;
    private javax.swing.JTextField NumberOfPagesTextField;
    private javax.swing.JLabel StringLabel;
    private javax.swing.JTextField StringTextField;
    private javax.swing.JLabel URLLabel;
    private javax.swing.JTextField URLTextField;
    private javax.swing.JCheckBox crawlAlgorithmBox;
    private javax.swing.JLabel iconLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel relevantCount;
    private java.awt.TextField relevantCountText;
    private java.awt.TextArea resultArea;
    private javax.swing.JLabel timeCount;
    private java.awt.TextField timeCountText;
    private javax.swing.JLabel totalCount;
    private java.awt.TextField totalCountText;
    // End of variables declaration//GEN-END:variables
    //Start of User declared variables
    URL url;
    URLQueue tempUrlQueue = new URLQueue();
    URLQueue completed = new URLQueue();
    ArrayList<String> tempArrayList = new ArrayList();
    TreeMap<String, Integer> assign = new TreeMap<>();
    LinkedHashMap<String, Integer> result = new LinkedHashMap<>();
    int BodyWeight;
    int TitleWeight;
    int URLWeight;
    int TotalWeight;
    int PageWeight;
    int totalLinks = 0;
    int startTime = (int) System.currentTimeMillis();
    //End of User declared variables

    /**
     *
     *
     * InternalMechanism function is used to initiate and continue execution of
     * main algorithm concept.
     *
     */
    private void InternalMechanism() throws MalformedURLException {
        try {
            String geturl = this.URLTextField.getText();
            this.url = new URL(geturl);
            String String1 = this.StringTextField.getText();
            String1 = stripSpecialCharacters(String1);
            String1 = String1.toLowerCase();

            if ((this.crawlAlgorithmBox.isSelected())) {

                this.resultArea.setText("");
                FetchPage wc = new FetchPage(this.url, String1);
                totalLinks = totalLinks + 1;

                /* If Crawling Algorithm is selected */
                if (this.crawlAlgorithmBox.isSelected()) {

                    if (("".equals(this.StringTextField.getText()))) {
                        JOptionPane.showMessageDialog(null, "\n\nCheck the String..\n\n", "ERROR", 1);
                    } else {
                        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

                        ArrayList<String> allotherurls = wc.otherUrls();

                        if (!allotherurls.isEmpty()) {

                            this.resultArea.setText("");
                            this.tempUrlQueue.clear();
                            this.completed.clear();
                            this.tempArrayList.clear();

                            this.PageWeight = wc.returnPageWeight();

                            this.completed.enqueue(geturl);
                            if (this.PageWeight > 1) {
                                assign.put(geturl, this.PageWeight);
                            }
                            Iterator itr = allotherurls.iterator();
                            while (itr.hasNext()) {

                                String otherlink = (String) itr.next();
                                this.tempUrlQueue.enqueue(otherlink);

                            }

                            while (!this.tempUrlQueue.isEmpty()) {
                                String tobefetched1 = this.tempUrlQueue.dequeue().toString();
                                if (!this.completed.hasThis(tobefetched1)) {
                                    this.completed.enqueue(tobefetched1);
                                    totalLinks++;
                                    URL newone1 = new URL(tobefetched1);
                                    FetchPage fetching1 = new FetchPage(newone1, String1);
                                    this.tempArrayList = fetching1.otherUrls();
                                    this.PageWeight = fetching1.returnPageWeight();
                                    if (this.PageWeight > 1) {
                                        assign.put(tobefetched1, this.PageWeight);
                                    }
                                    Iterator itr2 = this.tempArrayList.iterator();
                                    while (itr2.hasNext()) {
                                        String otherlinks = (String) itr2.next();
                                        this.tempUrlQueue.enqueue(otherlinks);
                                    }
                                    this.tempArrayList.clear();
                                }
                                if (this.completed.size() >= Integer.parseInt(this.NumberOfPagesTextField.getText())) {
                                    break;
                                }
                            }
                            setCursor(Cursor.getDefaultCursor());
                            int relcount = 0;
                            LinkedHashMap<String, Integer> finalMap = new LinkedHashMap();
                            finalMap.putAll(sortByValue(assign));

                            Iterator<Map.Entry<String, Integer>> entries = finalMap.entrySet().iterator();
                            while (entries.hasNext()) {
                                Map.Entry<String, Integer> entry = entries.next();
                                String text = entry.getKey();
                                Integer weight = entry.getValue();
                                String appendTotextarea = text + " : " + weight;
                                appendtextarea1(appendTotextarea);
                                relcount++;
                            }

                            int endTime = (int) System.currentTimeMillis();
                            int totalTime = endTime - startTime;
                            this.relevantCountText.setText(Integer.toString(relcount));
                            this.totalCountText.setText(Integer.toString(totalLinks));
                            this.timeCountText.setText(Integer.toString(totalTime));
                            if (relcount == 0) {
                                JOptionPane.showMessageDialog(null, "\n\nNo Match Found For Given Data\n\n", "ERROR", 1);
                            }
                        } else {
                            setCursor(Cursor.getDefaultCursor());
                            this.resultArea.setText("");
                            this.relevantCountText.setText(Integer.toString(0));
                            this.URLTextField.setEnabled(true);
                            this.StringTextField.setEnabled(true);
                            this.NumberOfPagesTextField.setEnabled(true);
                        }
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select the CheckBox", "Crawling Algorithm", 1);
                this.resultArea.setText("");
                this.URLTextField.setEnabled(true);
                this.StringTextField.setEnabled(true);
                this.NumberOfPagesTextField.setEnabled(true);
            }
        } catch (MalformedURLException ex) {
            String name = new Object() {
            }.getClass().getEnclosingMethod().getName();
            name = name + "\nDetails: " + " " + name + " " + ex.getCause() + " " + ex.getMessage() + " " + ex.getClass();
            RankLogger log = new RankLogger();
            log.getLogger(name);
        }
    }//end

    /**
     *
     *
     * sortByValue function is used to Sort the Resultant URL database.
     *
     * @param map
     * @return
     */
    public Map sortByValue(Map map) {
        List list = new LinkedList(map.entrySet());
        Collections.sort(list, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((Comparable) ((Map.Entry) (o2)).getValue())
                        .compareTo(((Map.Entry) (o1)).getValue());
            }
        });
        for (Iterator it = list.iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            result.put(entry.getKey().toString(), ((Integer) entry.getValue()).intValue());
        }
        return result;
    }

    /**
     *
     *
     * appendtextarea1 function is used to display the result to user.
     *
     * @param urls
     */
    public void appendtextarea1(String urls) {
        this.resultArea.append(urls + "\n");
    }

    /**
     *
     *
     * stripSpecialCharacters function is used to remove special symbol from
     * string.
     *
     * @param str
     * @return
     */
    public static String stripSpecialCharacters(String str) {

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (Character.isLetter(ch) || Character.isSpaceChar(ch)) {
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    public static void main(String args[]) throws IOException {
        /* Set the Nimbus look and feel */
        /* Create and display the form */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if (!"Nimbus".equals(info.getName())) {
                } else {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RankWebCrawler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RankWebCrawler().setVisible(true);
            }
        });
    }
}//end of main
//End of RankWebCrawler.java
